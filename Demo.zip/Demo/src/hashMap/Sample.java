package hashMap;
//
//import java.util.HashMap;
//import java.util.Map;
//import java.util.Map.Entry;
//import java.util.Set;
//
//public class Sample {
//	public static void main(String args[]) {
////		HashMap<String,Integer> map=new HashMap<String,Integer>();
////		map.put("Abi", 10);
////		map.put("Akas", 20);
////		map.put("Bii", 30);
////		map.put("GG", 40);
////		map.put("Gopi", 50);
////		Set<Entry<String,Integer>> entrySet=map.entrySet();
////		for(Entry<String,Integer> entry : entrySet()) {
////			System.out.println("Key="+)
////		}
//	     HashMap<String, Integer> map = new HashMap<String, Integer>();
//         
//	        //Inserting key-value pairs to map using put() method
//	         
//	        map.put("ONE", 1);
//	         
//	        map.put("TWO", 2);
//	         
//	        map.put("THREE", 3);
//	         
//	        map.put("FOUR", 4);
//	         
//	        map.put("FIVE", 5);
//	         
//	        //Printing key-value pairs 
//	         
//	        Set<Entry<K,V>> entrySet = map.entrySet();
//	         
//	        for (Map.Entry<String, Integer> entry : map.entrySet()) 
//	        {
//	            System.out.println(entry.getKey()+" : "+entry.getValue());
//	        }
//	}
//}

import java.util.HashMap;
import java.util.Map;
import java.util.*;
public class Sample {
 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Map<String,Integer> marks=new HashMap<>();
        marks.put("English", 95);
        marks.put("Tamil", 98);
        marks.put("Science", 87);
        marks.put("Maths", 97);
        for(String mark:marks.keySet()) {
        	System.out.println(mark+":"+marks.get(mark));
        }
	}
 
}

