package hashMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map;

	public class Example1 {
	public static void main(String args[]) {
		HashMap<String,String> hm=new HashMap<String,String>();
		hm.put("HR1234","Bus");
		hm.put("HR7365", "Train");
		hm.put("HR9876", "Car");
		hm.put("HR1235", "Train");
		String travelMode="bus";
		ArrayList<String> al=new ArrayList<>();
		ArrayList<String> res=new ArrayList<>();
		hm.forEach((key,value)->System.out.println("Key= "+key+" value="+value));
		for(String val:hm.keySet()) {
			if(val.equalsIgnoreCase("Bus")) {
				System.out.println(val);
			}
		}
//		String name="Hi all welcome to cognizant Technologies";
//		HashMap<Character,Integer> freq=new HashMap<>();
//		String nameword[]=name.split(" ");
//		for(String word:nameword) {
//			for(int i=0;i<word.length();i++) {
//				char ch=word.charAt(i);
//				if(freq.containsKey(ch)) {
//					freq.put(ch, freq.get(ch)+1);
//				}
//				else {
//					freq.put(ch, 1);
//				}
//			}
//		}
//		freq.forEach((key,value)->System.out.println("key= "+key+" value="+value));
	}
	}

