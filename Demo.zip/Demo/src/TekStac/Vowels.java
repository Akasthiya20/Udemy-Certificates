package TekStac;

public class Vowels {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="alive Pine ak";
		String res="";
		if(str.matches("[a-zA-Z ]+")) {
		String words[]=str.split(" ");
		int c=0;
		for(String word:words) {
			word=word.toLowerCase();
			if(word.charAt(0)=='a'||(word.charAt(0)=='e')||(word.charAt(0)=='i')||(word.charAt(0)=='o')||(word.charAt(0)=='u')){
				int len=word.length();
				String strlen=Integer.toString(len);
				res=res+" "+strlen;
				c++;
				//System.out.println("Successfull");
			}
			else {
				res=res+" "+word;
				//System.out.println("No data starts qith vowels");
			}
		}
		if(c>0) {
		System.out.println(res);
		}
		else {
			System.out.println("No vowels");
		}
		}
		else {
			System.out.println("Invalid data");
		}
	}

}
