package AdvancedJava;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class FileHandling {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileWriter fw=new FileWriter("output.txt",true);
		BufferedWriter bw=new BufferedWriter(fw);		
		bw.append("I understood about the concepts of FileWriter and BufferedWriter");
		bw.newLine();
		bw.append("Hii all");
		System.out.println("Success");
		//fw.close();
		bw.close();
	}
}
