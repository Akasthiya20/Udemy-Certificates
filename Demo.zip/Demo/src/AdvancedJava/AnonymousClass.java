package AdvancedJava;
//Inside class Anonymous class
class A{
	public void show() {
		System.out.println("Inside A class");
	}
}
public class AnonymousClass {
	public static void main(String args[]) {
		A obj=new A() 
		{
			public void show() {
				System.out.println("Inside new show");
			}
		};
		obj.show();
		
	}
}
