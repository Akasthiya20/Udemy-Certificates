package AdvancedJava;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class StreamsDemo {
	public static void main(String args[]) {
		List<Integer> list=Arrays.asList(1,2,3,2,9,9,1,2,6,6,9);
		//Stream<Integer> data=list.stream();
		//For sorting
//		Stream<Integer> sortedData=data.sorted();
//		sortedData.forEach(n->System.out.println(n));
		
		//double the value
		/*Stream<Integer> mappedData=data.map(n->n*2);
		mappedData.forEach(n->System.out.println(n));*/
		
		//Instead of adding the above lines do it in single line
		
//		list.stream()
//			.filter(n->n%2==1)
//			.sorted()
//			 .map(n->n*2)
//			 .forEach(n->System.out.println(n));
		
		int c=(int) list.stream().distinct().count();
		System.out.println(c);
		//explanation for above code is 
		
	/*	Predicate<Integer> predi=new Predicate<Integer>() {

			@Override
			public boolean test(Integer n) {
//				if(n%2==1) {
//					return true;
//				}
//				else {
//					return false;
//				}				// TODO Auto-generated method stub
				//Instead of the above code we can simply return the condition since it is going to return only the boolean value
				return n%2==1;
			}
		};*/
		
		//Sum of elements in array
//		int sumOfArray=list.stream()
//						   .reduce(0,(c,e)->c+e);
//		System.out.println("Sum of array is="+sumOfArray);
		
	}
}
