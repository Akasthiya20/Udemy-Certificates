package AdvancedJava;
//Functional Interface is the one which has only one method inside an interface it is by default public abstract


@FunctionalInterface
interface B
{
	void show();
}
public class FunctionalInterfaces {
 public static void main(String args[]) {
	 B obj=new B()
	 {
		public void show() {
			 System.out.println("Inside FunctionalInterface class");
		 }
	 };
	 obj.show();
 }
}
