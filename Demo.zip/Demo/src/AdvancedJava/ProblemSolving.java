package AdvancedJava;

import java.util.ArrayList;
import java.util.List;

public class ProblemSolving {
public static void main(String args[]) {
	String name="xyz";
	String rev="";
	//List<String> combinations=new ArrayList<String>();
	for(int i=name.length()-1;i>=0;i--){
		rev+=name.charAt(i);
	}
	System.out.println(rev);
}
}
