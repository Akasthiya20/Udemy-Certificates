package AdvancedJava;

interface C{
	void show(int a);
}
public class LambdaFunction {

	//Lambda Function is been used only in an functional Interface
	//This is been majorly used to reduce the code since the compiler will be fill the balance code 

	public static void main(String[] args) {
	/*Instead of doing all these things just use lambda symbol
		C obj=new C() {
			public void show() {
				System.out.println("Inside show");
			}
		};
		obj.show();*/
		
//		C obj =() -> System.out.println("Inside Lambda function");
//		obj.show();
		
	 //if we pass an one argument then it comes as
		
		//THis can be reduced as follows
		
		/*C obj=new C() {
			public void show(int a) {
				System.out.println("Inside C class");
			}
		};
		obj.show(5);*/
		
		C obj=(a)->System.out.println("Inside C class");
		obj.show(5);
	}

}
