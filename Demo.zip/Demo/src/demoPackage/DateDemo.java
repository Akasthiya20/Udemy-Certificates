package demoPackage;
import java.time.*;
import java.time.LocalDate;
import java.util.*;
public class DateDemo {
	public static void main(String args[]) {
		Date d=new Date();
		System.out.println(d);
		LocalDate ld=LocalDate.now();
		System.out.println(ld);
		System.out.println(ld.plusDays(10));
		System.out.println(ld.isLeapYear());
		LocalTime lt=LocalTime.now();
		System.out.println(lt);
	}
}
