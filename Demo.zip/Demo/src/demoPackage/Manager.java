package demoPackage;
import employee.Employees;
public class Manager extends Employees{
	String moj;
	Manager(int eId,String eName,float salary,String moj){
		super(eId,eName,salary);
		this.moj=moj;
	}
	void showMojDetails() {
		super.showEmployeeDetails();
		System.out.println(moj);
	}
public static void main(String args[]) {
	Manager m1=new Manager(1,"Virat",80000000,"Jan");
	m1.showMojDetails();
}
}
