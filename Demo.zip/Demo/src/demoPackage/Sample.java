package demoPackage;
import java.util.*;
public class Sample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	System.out.println("My first Project");
		int a=800,b=600,c=300;
		int max=a>b?(a>c?a:c):(b>c?b:c);
		int mark=60;
		String grade;
		System.out.println(max);
	/*	grade=switch(mark/10) {
		case 7,8,9,10 ->("Green");
		case 6 ->("Ambed");
		case 5->("Red");
		default->("Invalid");
		};
		System.out.println(grade);
		*/
		
		int i=10;
		i=i++;
		//System.out.println(i);
		i=i++;
		//System.out.println(i);
		grade=switch(mark/10) {
		case 7,8,9,10 :yield ("Green");
		case 6 :yield("Ambed");
		case 5:yield("Red");
		default:yield("Invalid");
		};
		//System.out.println(grade);
		Scanner sc=new Scanner(System.in);
		String choice=sc.nextLine();
		//if(choice.equalsIgnoreCase(choice))
	}

}