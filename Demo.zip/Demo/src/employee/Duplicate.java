package employee;
import java.util.*;
public class Duplicate {
public static void main(String args[]) {
	String input="DECEMBER";
	//HashMap<Character,Integer> hm=new HashMap<Character,Integer>();
	LinkedHashSet<String> lhs=new LinkedHashSet<>();
	String output="";
//	for (int i=0;i<input.length();i++) {
//		char ch=input.charAt(i);
//		if(hm.containsKey(ch)) {
//			hm.put(ch, hm.get(ch)+1);
//		}
//		else {
//			hm.put(ch, 1);
//			output+=ch;
//		}
//	}
	
	lhs.add(input);
	System.out.println(lhs);
}
}
