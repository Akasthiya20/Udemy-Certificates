package employee;

public class sampleStatic {

	
	static int eId=1;
	static String eName="AG";
	
	static void showEmployeeDetails() {
		System.out.println(eId+" "+eName);
	}

//	public sampleStatic(int eId,String eName){
//		eId=eId;
//		eName=eName;
//	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		showEmployeeDetails();
	}

}
