package employee;

public class Employees {
	protected int eId;
	protected String eName;
	protected float eSalary;
	
	public Employees(int eId,String eName,float eSalary){
		
		this.eId=eId;
		this.eName=eName;
		this.eSalary=eSalary;
		
	}
	//copy constructor
public Employees(Employees e){
		
	this.eId=e.eId;
	this.eName=e.eName;
	this.eSalary=e.eSalary;
		
	}
	public Employees(){
		this(2,"Abi",2000000);
		System.out.println("Default Constructor");
	}
public	void showEmployeeDetails() {
		System.out.println(eId+" "+eName+" "+eSalary);
	}
public static void main(String args[]) {
	Employees e1=new Employees();
	e1.showEmployeeDetails();
	//Copy constructor
	Employees e2=e1;
	e2.showEmployeeDetails();
	
	Employees e3=new Employees(3,"gg",5000000);
	e3.showEmployeeDetails();
	Employees e4=new Employees(e3);
	e4.showEmployeeDetails();
	
}
}
