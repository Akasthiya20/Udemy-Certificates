package employee;
import java.util.*;
public class SumOfDigits {
public static void main(String args[]) {
	System.out.println("Hi all");
	ArrayList<Integer> divBy6=new ArrayList<Integer>();
	ArrayList<Integer> ans=new ArrayList<Integer>();
	for(int i=1;i<=100;i++) {
		if(i%6==0) {
			divBy6.add(i);
		}
	}
	for(int i=0;i<divBy6.size();i++) {
		if(divBy6.get(i)>9) {
			int num=divBy6.get(i),rem,val=0;
			while(num>0) {
				rem=num%10;
				num=num/10;
				val+=rem;
			}
			if(val==3 || val==6 ||val==9) {
				ans.add(divBy6.get(i));
			}
		}
		else if(divBy6.get(i)==6){
			ans.add(divBy6.get(i));
		}
	}
	for(int num:ans) {
		System.out.println(num);
	}
}
}
