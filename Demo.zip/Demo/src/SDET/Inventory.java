package SDET;
import java.util.*;

//OOPS Concept
//Abstraction 

abstract class Inventory {
	//Using map to store products
    protected Map<Integer, Product> products;
    
    //Product Map is Initializes as an empty HashMap
    public Inventory() {
        products = new HashMap<>();
    }

    // Abstract methods (Abstraction)
    public abstract void addProduct(Product product);
    public abstract void updateQuantity(int id, int quantity);
    public abstract void deleteProduct(int id);
    public abstract void displayProducts();
}

