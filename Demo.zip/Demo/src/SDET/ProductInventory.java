package SDET;

import java.util.*;

class ProductInventory extends Inventory {
	
//Adding products into the list by mapping it with productId
    @Override
    public void addProduct(Product product) {
        products.put(product.getId(), product);
    }

    //updating the quantity of the product for the productId
    @Override
    public void updateQuantity(int id, int quantity) {
        Product product = products.get(id);
        if (product != null) {
            product.setQuantity(quantity);
        } else {
            System.out.println("Product with ID " + id + " not found.");
        }
    }
    
    //Deleting the Product based on its id
    @Override
    public void deleteProduct(int id) {
        products.remove(id);
    }
    
    //Displaying the entire product details that are been added to the list
    @Override
    public void displayProducts() {
    	//Adding all the products into ArrayList for easy manipulation process
        List<Product> productList = new ArrayList<>(products.values());
        
        // Sort the list by name through Bubble Sort
        for (int i = 0; i < productList.size() - 1; i++) {
            for (int j = i + 1; j < productList.size(); j++) {
                if (productList.get(i).getName().compareTo(productList.get(j).getName()) > 0) {
                    Collections.swap(productList, i, j);
                }
            }
        }
    
        //Displaying the products after sorting by names
        for (Product product : productList) {
            System.out.println(product);
        }
    }
}
