package SDET;

import java.util.Scanner;

public class InventoryManagementSystem {
    public static void main(String[] args) {
    	try {
        Inventory inventory = new ProductInventory();
        //To get inputs from user
        Scanner sc=new Scanner(System.in);
        
        //Declaring variables
        int id,quantity;
        String name;
        double price;
        int operation;
        
        //do-while to execute the operation until we try to exit
        do {
        System.out.println("Enter 1 to add products\nEnter 2 to Update\nEnter 3 to delete\nEnter 4 to delete\nEnter -1 to exit");
        operation=sc.nextInt();
        switch(operation) 
        {
        case 1: //Adding Products
        	 System.out.println("Enter no of products need to be added");
             int numberOfProducts=sc.nextInt();
             System.out.println("Enter the product details to add in the order of id,name,quantity,price");
             // Getting and Adding products to the list
             for(int i=1;i<=numberOfProducts;i++) {
             	 System.out.println("Enter product "+i+" id");
             	id=sc.nextInt();
            	 System.out.println("Enter product "+i+" name");
             	name=sc.next();
            	 System.out.println("Enter product "+i+" quantity");
             	quantity=sc.nextInt();
            	 System.out.println("Enter product "+i+" price");
             	price=sc.nextDouble();
             //Adding products to the list
                 inventory.addProduct(new Product(id,name,quantity,price));
             }
             break;
        case 2:    // Update quantity
        	 System.out.println("Enter the id that needed to be updated");
             int updateid=sc.nextInt();
           
             //Checking if the product Map contains the updateid only if it contains it will update it.
             //If not it will not be able update it
             if(inventory.products.containsKey(updateid)) {
             	  System.out.println("Enter the quantity that needed to be updated");
                   int updateQuantity=sc.nextInt();
             inventory.updateQuantity(updateid,updateQuantity);
             //After Updating checking whether it is reflected by displaying
             System.out.println("Updation Successfull!!!\nAfter Updating");
             inventory.displayProducts();
             }
             else {
             	System.out.println("Product ID "+ updateid +" not found. Update operation terminated.");
             }
             break;
        case 3: // Delete product
        	 System.out.println("Enter the id that need to be deleted");
             int deleteid=sc.nextInt();             
             //Checking if the product Map contains the id only if it contains it will delete it.
             //If not it will not be able delete it
             if(inventory.products.containsKey(deleteid)) {
             inventory.deleteProduct(deleteid);
             System.out.println("Deletion successful!!!");
             }
             else {
             	System.out.println("Product ID "+ deleteid +" not found.Delete operation terminated.");
             }
             break;
        case 4:       	 
            // Display products
            System.out.println("Displaying all the products");
            inventory.displayProducts();  
            break;

        case -1: // Exit
        	System.out.println("Exiting the program.");
        	break;
        default:
        	System.out.println("Invalid operation. Please enter a number between 1 and 4 or -1.");
        	break;
        }  
        }while(operation!=-1);
    }
    	catch(Exception e) {
    		System.out.println(e);
    	}       
    }
}
