package Udemy;

public class DemoStatic {
static int a=10;
int b=20;
static void m1() {
	System.out.println("Hello all");
}
void m2() {
	System.out.println("Welcome to java programming");
}
void nonStaticMethod() {
	System.out.println(a);
	m1();
	System.out.println(b);
	m2();
}
}
