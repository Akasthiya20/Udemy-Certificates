package Udemy;

public class Test {
	int number;
	void m1(int number) {
		number+=10;
		System.out.println("value in method "+number);
		}
	void m2(Test t) {
		t.number+=10;
		System.out.println("In Method "+t.number);
	}
}
