package Udemy;

public class EncapDemoMain {
public static void main(String args[]) {
	EncapDemo obj=new EncapDemo(1002,"Akas",100000.0d);
//	obj.setAccId(1002);
//	obj.setAccName("Akas");
//	obj.setSal(100000.0d);
	System.out.println(obj.getAccId());
	System.out.println(obj.getAccName());
	System.out.println(obj.getSal());
}
}
