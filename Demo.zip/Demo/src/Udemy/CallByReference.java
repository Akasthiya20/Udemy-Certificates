package Udemy;

// It will change since we are passing object as reference
public class CallByReference {
public static void main(String args[]) {
	Test t=new Test();
	t.number=10;
	System.out.println("Before method "+t.number);
	t.m2(t);
	System.out.println("After method "+t.number);
}
}
