package Udemy;

public class OverLoadMainMethod {
	int a=10;
	void main(int a) {
		System.out.println("A is "+a);
	}
	void main(int a,int b) {
		System.out.println("Sum of A and B is "+(a+b));
	}
public static void main(String args[]) {
	OverLoadMainMethod obj=new OverLoadMainMethod();
	obj.main(20);
	obj.main(10, 20);
}
}
