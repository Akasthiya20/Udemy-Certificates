package Udemy;

public class PassingParamsToMain {
	public static void main(String[] words) {
		for(String word:words) {
			System.out.println(word);
		}
	}
}
