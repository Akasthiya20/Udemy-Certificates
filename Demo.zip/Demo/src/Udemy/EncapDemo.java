package Udemy;

public class EncapDemo {
private int accId;
private String accName;
private double sal;

public EncapDemo(int accId, String accName, double sal) {
	super();
	this.accId = accId;
	this.accName = accName;
	this.sal = sal;
}


public int getAccId() {
	return accId;
}
public void setAccId(int accId) {
	this.accId = accId;
}
public String getAccName() {
	return accName;
}
public void setAccName(String accName) {
	this.accName = accName;
}
public double getSal() {
	return sal;
}
public void setSal(double sal) {
	this.sal = sal;
}

}
