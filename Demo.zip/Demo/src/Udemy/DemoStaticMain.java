package Udemy;
//if we are accessing static members outside of the same class then we have add the class name to access the members
public class DemoStaticMain {
public static void main(String args[] ){
	System.out.println(DemoStatic.a);
	DemoStatic.m1();
	DemoStatic ds=new DemoStatic();
	ds.m2();
	System.out.println(ds.b);
}

}
