package Udemy;

interface Shape{
	int length=10,width=20;  //final and static by default
	void circle();   //abstract method
	//default and static methods are applicable only onwards java 8
	default void rectangle() {
		System.out.println("Rectangle method...default method");
	}
	static void square() {
		System.out.println("Square Method...static");
	}
	
}
public class InterfaceDemo implements Shape
{
public void circle(){
  System.out.println("Circle method - abstract method...");
}

void triangle() {
	System.out.println("This is an normal method inside class...");
}
public static void main(String args[]) {
	//Scenario1
	InterfaceDemo idobj=new InterfaceDemo();
	idobj.circle();
	idobj.rectangle();
	System.out.println(Shape.length+Shape.width); //static variables
	Shape.square();
	idobj.triangle();
	//Scenario 2
	Shape idobj2=new InterfaceDemo();
	idobj2.circle();
	idobj2.rectangle();
	Shape.square();
	System.out.println(Shape.length+Shape.width);
	
	//idobj2.triangle()   #can't access
	
}
}
