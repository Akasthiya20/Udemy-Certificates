package Udemy;
//same variable use then use this keyword else no problem
public class ThisKeyword {
	int x,y;  //class or instance variable
	void setData(int x,int y) { // local variable
		this.x=x;
		this.y=y;
	}
	void display() {
		System.out.println("Class Variable x= "+x+" y="+y);
	}
public static void main(String args[]) {
	ThisKeyword t=new ThisKeyword();
	t.setData(10, 20);
	t.display();
}
}
