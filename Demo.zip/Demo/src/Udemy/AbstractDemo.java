package Udemy;

abstract class College{
	abstract void showCollegeDetails();
	void noOfDept() {
		System.out.println("There are 10 depts");
	}
}
public class AbstractDemo extends College{
	void showCollegeDetails() {
		System.out.println("College name is Dr.MCET");
	}
	public static void main(String args[]) {
	AbstractDemo ad=new AbstractDemo();
	ad.noOfDept();
	ad.showCollegeDetails();
	}
}
