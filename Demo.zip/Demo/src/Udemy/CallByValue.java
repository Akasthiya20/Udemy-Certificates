package Udemy;

//passing the copy of variable
public class CallByValue {
public static void main(String args[]) {
	int number=10;
	Test t=new Test();
	System.out.println("Before method: "+number);
	t.m1(number);
	//There is no change after the method passing since we are passing only the copy of the variable
	System.out.println("After method: "+number);
}
}
