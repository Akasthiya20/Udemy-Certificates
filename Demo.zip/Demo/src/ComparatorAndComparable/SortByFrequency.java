package ComparatorAndComparable;
import java.util.*;

public class SortByFrequency {
    public static void main(String[] args) {
        int[] input = {4, 5, 6, 5, 4, 3};
        int[] sortedArray = sortByFrequency(input);
        
        System.out.println("Input: " + Arrays.toString(input));
        System.out.println("Output: " + Arrays.toString(sortedArray));
    }

    public static int[] sortByFrequency(int[] arr) {
        // Count the frequency of each element
        Map<Integer, Integer> frequencyMap = new HashMap<>();
        for (int num : arr) {
            frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
        }

        // Create a list from the array
        List<Integer> list = new ArrayList<>();
        for (int num : arr) {
            list.add(num);
        }

        // Sort the list using a Comparator
        list.sort(new Comparator<Integer>() {
            @Override
            public int compare(Integer a, Integer b) {
                int freqA = frequencyMap.get(a);
                int freqB = frequencyMap.get(b);
                if (freqA != freqB) {
                    return freqB - freqA; // Descending order of frequency
                } else {
                    return a - b; // Ascending order of value
                }
            }
        });

        // Convert the list back to an array
        int[] sortedArray = new int[arr.length];
        for (int i = 0; i < list.size(); i++) {
            sortedArray[i] = list.get(i);
        }

        return sortedArray;
    }
}
