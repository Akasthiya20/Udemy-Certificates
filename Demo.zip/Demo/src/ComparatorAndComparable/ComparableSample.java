package ComparatorAndComparable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class Student implements Comparable<Student>{
	int age;
	String name;
	public Student(int age, String name) {
		super();
		this.age = age;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [age=" + age + ", name=" + name + "]";
	}
	
	public int compareTo(Student that) {
		if(this.age%10 > that.age%10)
			return 1;
		else
			return -1;
	}
	}

class ComparableSample {
	 public static void main(String args[]) {
			List<Student> studs=new ArrayList<Student>();
		//	Comparable<Integer> com=new Comparator<Integer>() {
		studs.add(new Student(21,"Abi"));
		studs.add(new Student(28,"Ak"));
		studs.add(new Student(12,"GG"));
		studs.add(new Student(10,"Akas"));
		studs.add(new Student(35,"DD"));
		studs.add(new Student(27,"KK"));

			Collections.sort(studs);
			for(Student stu:studs) {
				System.out.println(stu);
			}
		
	 }
}
