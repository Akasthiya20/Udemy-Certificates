package stepdefinitions;

import static org.testng.AssertJUnit.assertEquals;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import static org.testng.Assert.*;

import io.cucumber.java.en.*;

public class APISteps {

    Response response;

    @Given("I have the API endpoint")
    public void i_have_the_api_endpoint() {
        baseURI = "https://datausa.io/api/data?drilldowns=Nation&measures=Population&Year=2021";
    }

    @When("I send a GET request")
    public void i_send_a_get_request() {
        response = get();
    }

    @Then("the response status code should be {int}")
    public void the_response_status_code_should_be(Integer statusCode) {
        assertEquals(response.getStatusCode(), statusCode.intValue());
    }
}
