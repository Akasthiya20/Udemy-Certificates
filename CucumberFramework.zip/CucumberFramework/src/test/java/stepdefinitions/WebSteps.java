package stepdefinitions;


import static org.testng.AssertJUnit.assertEquals;
import io.cucumber.java.en.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import static org.testng.Assert.*;

public class WebSteps {
    WebDriver driver;

    @Given("I open the Google homepage")
    public void i_open_the_google_homepage() {
        driver = new ChromeDriver();
        driver.get("https://www.google.com");
    }

    @Then("the page title should be {string}")
    public void the_page_title_should_be(String expectedTitle) {
        assertEquals(driver.getTitle(), expectedTitle);
        driver.quit();
    }
}
